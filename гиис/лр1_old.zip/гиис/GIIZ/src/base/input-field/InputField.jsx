import * as React from "react";

function InputField({
  value = "",
  onChange = () => {},
  placeholder = "Введите текст",
  label = "Поле ввода"
}) {
  return (
    <div className="space-y-2">
      <input
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  );
};

export default InputField;