
export async function draw(p, drawPoint) {
    let x = 0;
    let y = 0;
    let limit = 1000;  // Ограничение для бесконечного роста
    
    // Рисуем начальную точку
    await drawPoint(x, y);
    
    // Основной цикл построения параболы
    while (x < limit) {
        x += 1;
        // Находим y по формуле параболы y² = 2px
        y = Math.sqrt(2 * p * x);
        
        // Рисуем точку
        await drawPoint(x, y);
    }
}