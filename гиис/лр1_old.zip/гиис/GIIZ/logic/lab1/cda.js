export async function draw(point1, point2, drawPoint) {
  // Находим наибольшую длину по горизонтали или вертикали, чтобы определить количество шагов
  const length = Math.max(
      Math.abs(point2.x - point1.x),
      Math.abs(point2.y - point1.y)
  );

  // Рисуем начальную точку
  await drawPoint(point1.x, point1.y);

  // высчитываем приращения (это позволяет рисовать равномерно)
  let dx = (point2.x - point1.x) / length;  
  let dy = (point2.y - point1.y) / length;  

  // Начальные значения x и y, сдвигаем их на половину шага, чтобы начать в правильном направлении
  let x = point1.x + 0.5 * Math.sign(dx);  
  let y = point1.y + 0.5 * Math.sign(dy);  

  await drawPoint(x, y);

  // Рисуем линию от начальной точки до конечной
  for (let i = 0; i < length; i++) {
      // Добалвяем приращение каждый шаг
      x = x + dx;
      y = y + dy;

      // если дошли до конечной точки
      if(x >= point2.x && y >= point2.y) {
          await drawPoint(point2.x, point2.y);
          break;
      }

      await drawPoint(x, y);
  }
}
