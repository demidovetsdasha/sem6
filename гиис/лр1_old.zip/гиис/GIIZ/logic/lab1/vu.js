export async function draw(point1, point2, drawPoint) {
    let x0 = point1.x;
    let y0 = point1.y;
    let x1 = point2.x;
    let y1 = point2.y;

    let dx = Math.abs(x1 - x0);
    let dy = Math.abs(y1 - y0);

    let steep = dy > dx; // Проверяем, крутой ли наклон

    if (steep) {
        // Если наклон крутой, меняем местами x и y
        [x0, y0] = [y0, x0];
        [x1, y1] = [y1, x1];
        [dx, dy] = [dy, dx];
    }

    if (x0 > x1) {
        // Если начальная точка правее конечной, меняем их местами
        [x0, x1] = [x1, x0];
        [y0, y1] = [y1, y0];
    }

    let gradient = dy / dx; // Вычисляем наклон
    let y = y0;
    for (let x = x0; x <= x1; x++) {
        if (steep) {
            await drawPoint(Math.round(y), x); // Если был крутой наклон, меняем x и y обратно
        } else {
            await drawPoint(x, Math.round(y));
        }
        y += gradient; // Двигаемся по оси Y
    }
}
