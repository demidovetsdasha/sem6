export async function draw(point1, point2, drawPoint) {
    let x = point1.x;
    let y = point1.y;

    let dx = point2.x - point1.x;
    let dy = point2.y - point1.y;

    // Инициализируем ошибку (e) на основе алгоритма Брезенхема
    let e = 2 * dy - dx;

    await drawPoint(x, y);

    let i = 1;

    // Цикл рисования линии по алгоритму Брезенхема
    while(i <= dx) {
        // Если ошибка больше или равна нулю, двигаем точку по Y
        if(e >= 0) {
            y = y + 1;  
            e = e - 2* dx;  // пересчитываем ошибку
        }

        // Всегда двигаем точку по X на 1
        x = x + 1;  
        e = e + 2 * dy;  // Корректируем ошибку на каждом шаге по X
        i = i + 1;

        // Если дошли до конечной точки
        if(x >= point2.x && y >= point2.y) {
            await drawPoint(point2.x, point2.y);
            break;
        }

        await drawPoint(x, y);
    }
}
